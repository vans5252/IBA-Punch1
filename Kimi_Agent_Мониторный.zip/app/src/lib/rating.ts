import type { RatingRow } from '@/types/game'

const KEY = 'iba-punch-rating-v1'

const BASE_RATING: RatingRow[] = [
  { name: 'АЛЕКСАНДР', score: 9857 },
  { name: 'ДМИТРИЙ', score: 9521 },
  { name: 'МИХАИЛ', score: 9487 },
  { name: 'АНДРЕЙ', score: 9370 },
  { name: 'АЛЕКСЕЙ', score: 9285 },
]

export function loadRating(): RatingRow[] {
  try {
    const raw = localStorage.getItem(KEY)
    if (raw) return JSON.parse(raw) as RatingRow[]
  } catch {
    /* ignore */
  }
  return BASE_RATING
}

/** Добавляет результат игрока («ВЫ») и возвращает новый рейтинг (топ-10) */
export function pushResult(score: number): RatingRow[] {
  const rows = loadRating().filter((r) => !r.you)
  rows.push({ name: 'ВЫ', score, you: true })
  rows.sort((a, b) => b.score - a.score)
  const top = rows.slice(0, 10)
  try {
    localStorage.setItem(KEY, JSON.stringify(top))
  } catch {
    /* ignore */
  }
  return top
}

export function resetRating(): RatingRow[] {
  try {
    localStorage.removeItem(KEY)
  } catch {
    /* ignore */
  }
  return BASE_RATING
}
