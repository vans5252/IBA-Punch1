import { useCallback, useEffect, useRef, useState } from 'react'
import {
  type GameState,
  PAY_TIMEOUT_SEC,
  READY_TIMEOUT_SEC,
  RESULT_TIMEOUT_SEC,
} from '@/types/game'
import { loadRating, pushResult, resetRating } from '@/lib/rating'

const initial = (): GameState => ({
  phase: 'IDLE',
  targetScore: 0,
  displayScore: 0,
  countdown: 3,
  attemptId: '',
  payTimer: PAY_TIMEOUT_SEC,
  rating: loadRating(),
})

const uid = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`.toUpperCase()

/**
 * Конечный автомат силомера.
 * isController=false — окно второго монитора: только слушает BroadcastChannel.
 */
export function useGameMachine(isController = true) {
  const [state, setState] = useState<GameState>(initial)
  const timers = useRef<number[]>([])
  const chan = useRef<BroadcastChannel | null>(null)

  const clearTimers = () => {
    timers.current.forEach((t) => window.clearTimeout(t))
    timers.current = []
  }
  const after = (ms: number, fn: () => void) => {
    timers.current.push(window.setTimeout(fn, ms))
  }

  // синхронизация состояния между окнами (основной 23" и верхний в козырьке)
  useEffect(() => {
    chan.current = new BroadcastChannel('iba-punch')
    if (!isController) {
      chan.current.onmessage = (e) => setState(e.data as GameState)
    }
    return () => chan.current?.close()
  }, [isController])

  useEffect(() => {
    if (isController) chan.current?.postMessage(state)
  }, [state, isController])

  /** Клиент отсканировал QR оплаты — показываем экран ожидания */
  const startPayment = useCallback(() => {
    if (!isController) return
    clearTimers()
    setState((s) => ({ ...s, phase: 'PAY_WAIT', payTimer: PAY_TIMEOUT_SEC }))
    // таймаут оплаты
    const tick = window.setInterval(() => {
      setState((s) => {
        if (s.phase !== 'PAY_WAIT') {
          window.clearInterval(tick)
          return s
        }
        if (s.payTimer <= 1) {
          window.clearInterval(tick)
          return { ...s, phase: 'IDLE', payTimer: PAY_TIMEOUT_SEC }
        }
        return { ...s, payTimer: s.payTimer - 1 }
      })
    }, 1000)
    timers.current.push(tick as unknown as number)
  }, [isController])

  /** Платёж подтверждён: груша откидывается, отсчёт 3-2-1 */
  const confirmPayment = useCallback(() => {
    if (!isController) return
    clearTimers()
    const attemptId = uid()
    setState((s) => ({ ...s, phase: 'COUNTDOWN', countdown: 3, attemptId }))
    after(1100, () => setState((s) => ({ ...s, countdown: 2 })))
    after(2200, () => setState((s) => ({ ...s, countdown: 1 })))
    after(3300, () => setState((s) => ({ ...s, phase: 'READY', countdown: 0 })))
    // если удара нет — возврат в IDLE
    after(3300 + READY_TIMEOUT_SEC * 1000, () =>
      setState((s) => (s.phase === 'READY' ? { ...s, phase: 'IDLE' } : s)),
    )
  }, [isController])

  /**
   * Регистрация удара.
   * @param forceNewtons измеренная сила, Н (датчик) — в тесте задаётся ползунком
   */
  const registerPunch = useCallback(
    (forceNewtons: number) => {
      if (!isController) return
      const score = Math.max(100, Math.min(9999, Math.round(forceNewtons * 1.6)))
      clearTimers()
      setState((s) =>
        s.phase === 'READY'
          ? { ...s, phase: 'COUNTING', targetScore: score, displayScore: 0 }
          : s,
      )

      // плавный набор числа с замедлением (ease-out), ~2.6 c
      const DURATION = 2600
      const t0 = performance.now()
      const step = (t: number) => {
        const k = Math.min(1, (t - t0) / DURATION)
        const eased = 1 - Math.pow(1 - k, 3)
        const val = Math.round(eased * score)
        setState((s) =>
          s.phase === 'COUNTING' ? { ...s, displayScore: val } : s,
        )
        if (k < 1) {
          requestAnimationFrame(step)
        } else {
          setState((s) => ({
            ...s,
            phase: 'RESULT',
            displayScore: score,
            rating: pushResult(score),
          }))
          after(RESULT_TIMEOUT_SEC * 1000, () =>
            setState(() => ({ ...initial(), rating: loadRating() })),
          )
        }
      }
      requestAnimationFrame(step)
    },
    [isController],
  )

  /** Сброс автомата в исходное состояние */
  const reset = useCallback(() => {
    if (!isController) return
    clearTimers()
    setState({ ...initial(), rating: resetRating() })
  }, [isController])

  const backToIdle = useCallback(() => {
    if (!isController) return
    clearTimers()
    setState((prev) => ({ ...initial(), rating: prev.rating }))
  }, [isController])

  return { state, startPayment, confirmPayment, registerPunch, reset, backToIdle }
}
