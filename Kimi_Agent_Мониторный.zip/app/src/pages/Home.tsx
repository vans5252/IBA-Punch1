import { useEffect, useState } from 'react'
import { useGameMachine } from '@/hooks/useGameMachine'
import { MainScreen } from '@/components/MainScreen'
import { TopScreen } from '@/components/TopScreen'
import { TestPanel } from '@/components/TestPanel'

type View = 'both' | 'main' | 'top'

/**
 * Режимы запуска:
 *  — по умолчанию: ПК-тест, оба экрана + панель теста;
 *  — ?screen=main: окно основного 23" монитора (управляющее);
 *  — ?screen=top:  окно монитора в козырьке (ведомое, sync по BroadcastChannel);
 *  — ?kiosk=1:     без панели теста и переключателя (боевой режим).
 */
export default function Home() {
  const params = new URLSearchParams(window.location.search)
  const screenParam = params.get('screen')
  const kiosk = params.get('kiosk') === '1' || !!screenParam
  const isController = screenParam !== 'top'

  const machine = useGameMachine(isController)
  const [view, setView] = useState<View>(
    screenParam === 'main' ? 'main' : screenParam === 'top' ? 'top' : 'both',
  )

  // ПРОБЕЛ — удар (тест с ПК)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault()
        if (machine.state.phase === 'READY') {
          machine.registerPunch(2800 + Math.random() * 3200)
        }
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [machine])

  const frame = 'overflow-hidden rounded-xl border-2 border-neutral-800 bg-black shadow-[0_0_40px_rgba(255,20,40,.15)]'

  return (
    <div className="min-h-screen bg-[#0a0a0c] p-4">
      {!kiosk && (
        <div className="mx-auto mb-4 flex max-w-5xl items-center justify-between rounded-xl border border-neutral-800 bg-neutral-950 px-5 py-3">
          <span className="font-display tracking-widest text-neutral-300">
            РЕЖИМ ТЕСТИРОВАНИЯ С ПК
          </span>
          <div className="flex gap-2">
            {(
              [
                ['both', 'Оба экрана'],
                ['main', 'Основной 23″'],
                ['top', 'Верхний (козырёк)'],
              ] as [View, string][]
            ).map(([v, label]) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`rounded-lg px-4 py-2 font-display text-sm tracking-wider transition ${
                  view === v
                    ? 'bg-red-700 text-white'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      )}

      {view === 'both' && !kiosk ? (
        <div className="mx-auto flex max-w-[1500px] flex-col gap-4">
          <div className={frame} style={{ aspectRatio: '16/9' }}>
            <TopScreen state={machine.state} />
          </div>
          <div className={frame} style={{ aspectRatio: '16/9' }}>
            <MainScreen state={machine.state} />
          </div>
        </div>
      ) : (
        <div className={kiosk ? 'fixed inset-0' : 'mx-auto max-w-[1500px]'}>
          <div className={kiosk ? 'h-full w-full' : frame} style={kiosk ? {} : { aspectRatio: '16/9' }}>
            {view === 'main' ? (
              <MainScreen state={machine.state} />
            ) : (
              <TopScreen state={machine.state} />
            )}
          </div>
        </div>
      )}

      {!kiosk && (
        <TestPanel
          phase={machine.state.phase}
          onStartPayment={machine.startPayment}
          onConfirmPayment={machine.confirmPayment}
          onPunch={machine.registerPunch}
          onReset={machine.reset}
        />
      )}
    </div>
  )
}
