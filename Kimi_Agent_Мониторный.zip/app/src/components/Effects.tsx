import { useEffect, useMemo, useState } from 'react'

/** Полноэкранная вспышка при ударе */
export function ImpactFlash({ trigger }: { trigger: number }) {
  const [on, setOn] = useState(false)
  useEffect(() => {
    if (!trigger) return
    setOn(true)
    const t = setTimeout(() => setOn(false), 450)
    return () => clearTimeout(t)
  }, [trigger])
  if (!on) return null
  return <div className="pointer-events-none absolute inset-0 z-40 animate-flash bg-red-600" />
}

/** Летящие частицы-искры при ударе */
export function Sparks({ trigger }: { trigger: number }) {
  const parts = useMemo(
    () =>
      Array.from({ length: 26 }, (_, i) => ({
        id: `${trigger}-${i}`,
        angle: Math.random() * 360,
        dist: 120 + Math.random() * 320,
        size: 3 + Math.random() * 7,
        delay: Math.random() * 0.15,
        color: Math.random() > 0.4 ? '#ff2233' : '#ffd34d',
      })),
    [trigger],
  )
  if (!trigger) return null
  return (
    <div className="pointer-events-none absolute inset-0 z-40 overflow-hidden">
      {parts.map((p) => (
        <span
          key={p.id}
          className="absolute left-1/2 top-1/2 rounded-full animate-spark"
          style={
            {
              width: p.size,
              height: p.size,
              background: p.color,
              boxShadow: `0 0 10px ${p.color}`,
              animationDelay: `${p.delay}s`,
              '--dx': `${Math.cos((p.angle * Math.PI) / 180) * p.dist}px`,
              '--dy': `${Math.sin((p.angle * Math.PI) / 180) * p.dist}px`,
            } as React.CSSProperties
          }
        />
      ))}
    </div>
  )
}

/** Большая цифра отсчёта 3-2-1 */
export function CountdownDigit({ value }: { value: number }) {
  return (
    <div
      key={value}
      className="animate-countdown font-display text-[16rem] leading-none text-red-500"
      style={{ textShadow: '0 0 60px rgba(255,30,40,.9), 0 0 120px rgba(255,30,40,.5)' }}
    >
      {value}
    </div>
  )
}

/** Оценка результата по очкам */
export function verdict(score: number): string {
  if (score >= 9500) return 'НЕВЕРОЯТНО! УРОВЕНЬ ЧЕМПИОНА!'
  if (score >= 8500) return 'МОЩНЕЙШИЙ УДАР!'
  if (score >= 7000) return 'ОТЛИЧНЫЙ УДАР!'
  if (score >= 5000) return 'ХОРОШИЙ УДАР!'
  if (score >= 3000) return 'НЕПЛОХО! ТРЕНИРУЙСЯ!'
  return 'РАЗМИНКА. ПОПРОБУЙ ЕЩЁ!'
}
