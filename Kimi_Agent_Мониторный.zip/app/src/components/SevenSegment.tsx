// Семисегментный LED-индикатор в стиле классических силомеров
//      --a--
//     |     |
//     f     b
//     |--g--|
//     e     c
//     |     |
//      --d--
const SEGMENTS: Record<string, string[]> = {
  '0': ['a', 'b', 'c', 'd', 'e', 'f'],
  '1': ['b', 'c'],
  '2': ['a', 'b', 'g', 'e', 'd'],
  '3': ['a', 'b', 'g', 'c', 'd'],
  '4': ['f', 'g', 'b', 'c'],
  '5': ['a', 'f', 'g', 'c', 'd'],
  '6': ['a', 'f', 'g', 'e', 'c', 'd'],
  '7': ['a', 'b', 'c'],
  '8': ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
  '9': ['a', 'b', 'c', 'd', 'f', 'g'],
}

// полигоны сегментов в поле 100x180
const SHAPES: Record<string, string> = {
  a: '14,6 86,6 76,20 24,20',
  b: '88,10 98,16 88,84 78,70',
  c: '86,96 96,102 86,170 76,156',
  d: '14,174 86,174 76,160 24,160',
  e: '12,96 22,102 12,170 2,164',
  f: '14,10 24,16 14,84 4,78',
  g: '16,90 84,90 74,104 26,104',
}

function Digit({ ch, size = 90 }: { ch: string; size?: number }) {
  const active = SEGMENTS[ch] ?? []
  const h = size * 1.8
  return (
    <svg
      width={size}
      height={h}
      viewBox="0 0 100 180"
      style={{ filter: 'drop-shadow(0 0 14px rgba(255,30,40,.85))' }}
    >
      {/* погашенные сегменты — тёмный фон */}
      {Object.entries(SHAPES).map(([seg, pts]) => (
        <polygon key={seg} points={pts} fill="rgba(120,10,18,0.22)" />
      ))}
      {active.map((seg) => (
        <polygon key={seg} points={SHAPES[seg]} fill="#ff1e28" />
      ))}
    </svg>
  )
}

export function SevenSegmentNumber({
  value,
  digits = 4,
  size = 90,
}: {
  value: number
  digits?: number
  size?: number
}) {
  const str = String(Math.max(0, Math.min(10 ** digits - 1, value))).padStart(digits, '0')
  return (
    <div className="flex items-end gap-2">
      {str.split('').map((ch, i) => (
        <Digit key={i} ch={ch} size={size} />
      ))}
    </div>
  )
}
