import { useState } from 'react'
import type { GamePhase } from '@/types/game'

interface Props {
  phase: GamePhase
  onStartPayment: () => void
  onConfirmPayment: () => void
  onPunch: (force: number) => void
  onReset: () => void
}

const PHASE_NAMES: Record<GamePhase, string> = {
  IDLE: 'Ожидание',
  PAY_WAIT: 'Оплата',
  COUNTDOWN: 'Отсчёт 3-2-1',
  READY: 'Готов к удару',
  COUNTING: 'Набор очков',
  RESULT: 'Результат',
}

/**
 * Панель тестирования с ПК: эмулирует платёжный терминал и датчик удара.
 * Клавиша ПРОБЕЛ — удар (когда автомат в состоянии READY).
 */
export function TestPanel({ phase, onStartPayment, onConfirmPayment, onPunch, onReset }: Props) {
  const [force, setForce] = useState(5800)
  const [open, setOpen] = useState(true)

  if (!open)
    return (
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-4 right-4 z-50 rounded-lg bg-red-700 px-4 py-2 font-display text-sm text-white"
      >
        ТЕСТ
      </button>
    )

  const btn =
    'rounded-lg px-4 py-2 font-display text-sm tracking-wider transition disabled:cursor-not-allowed disabled:opacity-30'

  return (
    <div className="fixed bottom-4 right-4 z-50 w-80 rounded-2xl border border-red-800/50 bg-neutral-950/95 p-4 text-neutral-200 shadow-2xl backdrop-blur">
      <div className="mb-3 flex items-center justify-between">
        <span className="font-display tracking-widest text-red-500">ПАНЕЛЬ ТЕСТА</span>
        <button onClick={() => setOpen(false)} className="text-neutral-500 hover:text-white">
          ✕
        </button>
      </div>

      <div className="mb-3 rounded-lg bg-neutral-900 px-3 py-2 font-mono text-sm">
        Состояние: <span className="text-red-400">{PHASE_NAMES[phase]}</span>
      </div>

      <div className="space-y-2">
        <button
          onClick={onStartPayment}
          disabled={phase !== 'IDLE'}
          className={`${btn} w-full bg-neutral-800 hover:bg-neutral-700`}
        >
          1. Сканировать QR оплаты
        </button>
        <button
          onClick={onConfirmPayment}
          disabled={phase !== 'PAY_WAIT'}
          className={`${btn} w-full bg-green-800 hover:bg-green-700`}
        >
          2. Симулировать оплату
        </button>

        <div className="rounded-lg bg-neutral-900 p-3">
          <label className="mb-1 block font-mono text-xs text-neutral-400">
            Сила удара: <span className="text-red-400">{force} Н</span>
          </label>
          <input
            type="range"
            min={500}
            max={6200}
            step={50}
            value={force}
            onChange={(e) => setForce(Number(e.target.value))}
            className="w-full accent-red-600"
          />
          <button
            onClick={() => onPunch(force)}
            disabled={phase !== 'READY'}
            className={`${btn} mt-2 w-full bg-red-700 text-white hover:bg-red-600`}
          >
            3. УДАРИТЬ (ПРОБЕЛ)
          </button>
        </div>

        <button onClick={onReset} className={`${btn} w-full bg-neutral-800 hover:bg-neutral-700`}>
          Сброс автомата
        </button>
      </div>
    </div>
  )
}
