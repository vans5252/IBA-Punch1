import type { GameState } from '@/types/game'
import { SevenSegmentNumber } from './SevenSegment'
import { CountdownDigit } from './Effects'
import splash from '@/assets/splash.jpg'
import logo from '@/assets/logo.png'

/**
 * Верхний монитор в козырьке:
 * IDLE/PAY_WAIT — заставка; COUNTDOWN — отсчёт; READY — «БЕЙ!»;
 * COUNTING/RESULT — крупный счёт для зрителей.
 */
export function TopScreen({ state }: { state: GameState }) {
  const { phase } = state

  return (
    <div className="relative h-full w-full overflow-hidden bg-black">
      {(phase === 'IDLE' || phase === 'PAY_WAIT') && (
        <>
          <img src={splash} alt="IBA PUNCH" className="h-full w-full object-cover" />
          <div className="absolute inset-x-0 bottom-6 flex justify-center">
            <span className="font-display text-3xl tracking-[0.4em] text-red-500 animate-pulse">
              СИЛА В ТЕБЕ!
            </span>
          </div>
        </>
      )}

      {phase === 'COUNTDOWN' && (
        <div className="flex h-full flex-col items-center justify-center gap-4 bg-black">
          <img src={logo} alt="" className="w-64 opacity-90" />
          <CountdownDigit value={state.countdown} />
          <span className="font-display text-2xl tracking-[0.5em] text-neutral-400">
            ПРИГОТОВЬСЯ
          </span>
        </div>
      )}

      {phase === 'READY' && (
        <div className="flex h-full flex-col items-center justify-center bg-black">
          <span
            className="animate-hit font-display text-[13rem] leading-none text-red-500"
            style={{ textShadow: '0 0 80px rgba(255,30,40,.9)' }}
          >
            БЕЙ!
          </span>
        </div>
      )}

      {(phase === 'COUNTING' || phase === 'RESULT') && (
        <div className="flex h-full flex-col items-center justify-center gap-2 bg-black">
          <span className="font-display text-3xl tracking-[0.4em] text-neutral-300">СЧЁТ</span>
          <SevenSegmentNumber value={state.displayScore} size={110} />
          {phase === 'RESULT' && (
            <span className="mt-2 font-display text-2xl tracking-[0.3em] text-red-500 animate-pulse">
              НОВЫЙ РЕЗУЛЬТАТ!
            </span>
          )}
        </div>
      )}
    </div>
  )
}
