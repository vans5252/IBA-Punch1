import { useEffect, useState } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import type { GameState } from '@/types/game'
import { paymentUrl, resultUrl, PRICE_RUB } from '@/types/game'
import { SevenSegmentNumber } from './SevenSegment'
import { RatingTable } from './RatingTable'
import { ImpactFlash, Sparks, CountdownDigit, verdict } from './Effects'
import logo from '@/assets/logo.png'
import boxerLeft from '@/assets/boxer-left.png'
import boxerRight from '@/assets/boxer-right.png'
import gloves from '@/assets/gloves.png'

function Clock() {
  const [now, setNow] = useState(new Date())
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(t)
  }, [])
  const time = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })
  const date = now.toLocaleDateString('ru-RU')
  return (
    <div className="text-right leading-tight">
      <div className="font-mono text-4xl font-bold text-neutral-100">{time}</div>
      <div className="font-mono text-lg text-neutral-400">{date}</div>
    </div>
  )
}

function Header({ title }: { title: string }) {
  return (
    <div className="relative z-10 flex items-start justify-between px-8 pt-6">
      <img src={logo} alt="IBA PUNCH" className="w-44 drop-shadow-[0_0_18px_rgba(255,30,40,.35)]" />
      <h1 className="pt-3 font-display text-3xl tracking-[0.25em] text-neutral-100">{title}</h1>
      <Clock />
    </div>
  )
}

/** Нижняя панель: рейтинг + перчатки + инструкция (как на референсе) */
function BottomPanel({ state }: { state: GameState }) {
  return (
    <div className="relative z-10 mx-6 mb-4 rounded-2xl border border-red-900/40 bg-black/70 p-5 backdrop-blur">
      <div className="grid grid-cols-[1.1fr_auto_1.2fr] items-center gap-6">
        <RatingTable rows={state.rating.slice(0, 7)} compact />
        <img src={gloves} alt="" className="h-56 object-contain drop-shadow-[0_0_25px_rgba(255,30,40,.4)]" />
        <div>
          <h3 className="mb-3 font-display text-xl tracking-widest text-neutral-200">
            КАК СОХРАНИТЬ РЕЗУЛЬТАТ?
          </h3>
          <ol className="space-y-3 text-neutral-300">
            {[
              ['1.', 'СКАНИРУЙ QR-КОД'],
              ['2.', 'ВОЙДИ В ЛИЧНЫЙ КАБИНЕТ ИЛИ ЗАРЕГИСТРИРУЙСЯ'],
              ['3.', 'ТВОЙ РЕЗУЛЬТАТ ПОЯВИТСЯ В РЕЙТИНГЕ'],
            ].map(([n, text]) => (
              <li key={n} className="flex items-start gap-3">
                <span className="font-display text-xl text-red-500">{n}</span>
                <span className="font-display text-base tracking-wider">{text}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between border-t border-red-900/30 pt-2 text-neutral-500">
        <span className="font-mono text-sm">PUNCHNET ОНЛАЙН</span>
        <span className="font-display text-lg tracking-[0.35em] text-red-500">IBA PUNCH · СИЛА В ТЕБЕ!</span>
        <span className="font-mono text-sm">24/7</span>
      </div>
    </div>
  )
}

export function MainScreen({ state }: { state: GameState }) {
  const { phase } = state
  const shake = phase === 'COUNTING'

  return (
    <div
      className={`relative flex h-full w-full flex-col overflow-hidden bg-[#070709] ${shake ? 'animate-shake' : ''}`}
    >
      {/* фоновые боксёры */}
      <img
        src={boxerLeft}
        alt=""
        className="pointer-events-none absolute -left-10 bottom-24 z-0 h-[62%] object-contain opacity-80"
      />
      <img
        src={boxerRight}
        alt=""
        className="pointer-events-none absolute -right-10 bottom-24 z-0 h-[62%] object-contain opacity-80"
      />
      {/* гексагональный фон поверх */}
      <div className="hex-bg pointer-events-none absolute inset-0 z-0 opacity-60" />

      <ImpactFlash trigger={phase === 'COUNTING' ? 1 : 0} />
      <Sparks trigger={phase === 'COUNTING' ? 1 : 0} />

      {/* ============ IDLE: привлечение + QR оплаты ============ */}
      {phase === 'IDLE' && (
        <>
          <Header title="ПРОВЕРЬ СВОЮ СИЛУ УДАРА!" />
          <div className="relative z-10 flex flex-1 items-center justify-center gap-10">
            <div className="text-center">
              <div className="font-display text-2xl tracking-[0.3em] text-red-500">УДАРЬ ГРУШУ</div>
              <div className="font-display text-2xl tracking-[0.3em] text-red-500">И УЗНАЙ СВОЮ СИЛУ</div>
              <div className="mt-4 font-display text-5xl text-neutral-100">{PRICE_RUB} ₽</div>
              <div className="mt-1 font-mono text-neutral-400">1 попытка</div>
            </div>
            <div className="flex items-center gap-5">
              <div className="text-right font-display text-xl leading-snug tracking-wider text-neutral-200">
                СКАНИРУЙ QR-КОД
                <br />
                <span className="text-sm text-neutral-400">ЧТОБЫ ОПЛАТИТЬ И НАЧАТЬ</span>
              </div>
              <div className="animate-pulse font-display text-4xl text-red-500">➤</div>
              <div className="rounded-xl bg-white p-3 shadow-[0_0_35px_rgba(255,30,40,.35)]">
                <QRCodeSVG value={paymentUrl()} size={170} level="M" />
              </div>
            </div>
          </div>
          <BottomPanel state={state} />
        </>
      )}

      {/* ============ PAY_WAIT: ожидание оплаты ============ */}
      {phase === 'PAY_WAIT' && (
        <>
          <Header title="ОПЛАТА" />
          <div className="relative z-10 flex flex-1 flex-col items-center justify-center gap-6">
            <div className="rounded-2xl bg-white p-5 shadow-[0_0_50px_rgba(255,30,40,.5)]">
              <QRCodeSVG value={paymentUrl()} size={260} level="M" />
            </div>
            <div className="font-display text-3xl tracking-[0.2em] text-neutral-100">
              ОПЛАТИТЕ {PRICE_RUB} ₽
            </div>
            <div className="font-mono text-xl text-neutral-400">
              Ожидание платежа… {state.payTimer} с
            </div>
            <div className="h-2 w-80 overflow-hidden rounded-full bg-neutral-800">
              <div
                className="h-full bg-red-600 transition-all duration-1000"
                style={{ width: `${(state.payTimer / 60) * 100}%` }}
              />
            </div>
          </div>
        </>
      )}

      {/* ============ COUNTDOWN: груша откинута, 3-2-1 ============ */}
      {phase === 'COUNTDOWN' && (
        <div className="relative z-10 flex flex-1 flex-col items-center justify-center gap-4">
          <img src={logo} alt="" className="w-72" />
          <div className="font-display text-2xl tracking-[0.4em] text-neutral-300">
            ГРУША ОПУЩЕНА · ВСТАНЬ В СТОЙКУ
          </div>
          <CountdownDigit value={state.countdown} />
        </div>
      )}

      {/* ============ READY: сигнал бить ============ */}
      {phase === 'READY' && (
        <div className="relative z-10 flex flex-1 flex-col items-center justify-center">
          <span
            className="animate-hit font-display text-[11rem] leading-none text-red-500"
            style={{ textShadow: '0 0 70px rgba(255,30,40,.9)' }}
          >
            БЕЙ!
          </span>
          <span className="mt-4 font-display text-2xl tracking-[0.4em] text-neutral-300 animate-pulse">
            УДАРЬ ПО ГРУШЕ СО ВСЕЙ СИЛЫ
          </span>
        </div>
      )}

      {/* ============ COUNTING: плавный набор очков ============ */}
      {phase === 'COUNTING' && (
        <div className="relative z-10 flex flex-1 flex-col items-center justify-center gap-2">
          <span className="font-display text-3xl tracking-[0.35em] text-red-500">ВАШ УДАР</span>
          <SevenSegmentNumber value={state.displayScore} size={130} />
          <span className="font-display text-2xl tracking-[0.35em] text-red-500">ОЧКИ</span>
        </div>
      )}

      {/* ============ RESULT: итог + QR результата + рейтинг ============ */}
      {phase === 'RESULT' && (
        <>
          <Header title={verdict(state.targetScore)} />
          <div className="relative z-10 flex flex-1 items-center justify-center gap-12">
            <div className="flex flex-col items-center gap-1">
              <span className="font-display text-2xl tracking-[0.35em] text-red-500">ВАШ УДАР</span>
              <SevenSegmentNumber value={state.displayScore} size={110} />
              <span className="font-display text-xl tracking-[0.35em] text-red-500">ОЧКИ</span>
            </div>
            <div className="flex items-center gap-5">
              <div className="text-right font-display text-xl leading-snug tracking-wider text-neutral-200">
                СКАНИРУЙ QR-КОД
                <br />
                <span className="text-sm text-neutral-400">
                  ЧТОБЫ СОХРАНИТЬ РЕЗУЛЬТАТ
                  <br />И СРАВНИТЬ СЯ С ДРУГИМИ
                </span>
              </div>
              <div className="animate-pulse font-display text-4xl text-red-500">➤</div>
              <div className="rounded-xl bg-white p-3 shadow-[0_0_35px_rgba(255,30,40,.45)]">
                <QRCodeSVG
                  value={resultUrl(state.targetScore, state.attemptId)}
                  size={180}
                  level="M"
                />
              </div>
            </div>
          </div>
          <BottomPanel state={state} />
        </>
      )}
    </div>
  )
}
