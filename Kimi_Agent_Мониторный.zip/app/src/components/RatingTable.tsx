import type { RatingRow } from '@/types/game'

export function RatingTable({ rows, compact = false }: { rows: RatingRow[]; compact?: boolean }) {
  return (
    <div className="w-full">
      <h3
        className={`font-display tracking-widest text-neutral-200 ${compact ? 'text-lg' : 'text-2xl'} mb-2`}
      >
        РЕЙТИНГ МЕСЯЦА
      </h3>
      <table className="w-full border-collapse">
        <tbody>
          {rows.map((r, i) => (
            <tr
              key={`${r.name}-${i}`}
              className={
                r.you
                  ? 'text-red-500 font-bold animate-pulse'
                  : i < 3
                    ? 'text-neutral-100'
                    : 'text-neutral-400'
              }
            >
              <td className={`${compact ? 'py-0.5 text-sm' : 'py-1 text-xl'} w-10 text-red-500/80 font-display`}>
                {i + 1}
              </td>
              <td className={`${compact ? 'text-sm' : 'text-xl'} font-display tracking-wider`}>
                {r.name}
              </td>
              <td className={`${compact ? 'text-sm' : 'text-xl'} text-right font-mono`}>
                {r.score}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
