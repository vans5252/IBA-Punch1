// Состояния конечного автомата силомера IBA PUNCH
export type GamePhase =
  | 'IDLE'       // режим привлечения: QR оплаты + рейтинг
  | 'PAY_WAIT'   // клиент сканирует QR оплаты, ждём подтверждение
  | 'COUNTDOWN'  // оплата прошла: груша откидывается, отсчёт 3-2-1
  | 'READY'      // сигнал «БЕЙ!» — ждём удар по груше
  | 'COUNTING'   // удар зафиксирован: число плавно набирается
  | 'RESULT'     // итог: счёт + QR с результатом + рейтинг

export interface RatingRow {
  name: string
  score: number
  you?: boolean
}

export interface GameState {
  phase: GamePhase
  /** целевой результат текущей попытки, очки */
  targetScore: number
  /** отображаемый (анимированный) счёт */
  displayScore: number
  /** номер шага отсчёта 3-2-1 */
  countdown: number
  /** id попытки для QR результата */
  attemptId: string
  /** оставшееся время ожидания оплаты, сек */
  payTimer: number
  /** рейтинг месяца */
  rating: RatingRow[]
}

export const PAY_TIMEOUT_SEC = 60
export const RESULT_TIMEOUT_SEC = 25
export const READY_TIMEOUT_SEC = 12
export const PRICE_RUB = 100
export const MACHINE_ID = 'IBA-001'

/** URL, вшитый в QR оплаты */
export const paymentUrl = () =>
  `https://pay.punchnet.online/pay?machine=${MACHINE_ID}&amount=${PRICE_RUB}&ts=${Date.now()}`

/** URL, вшитый в QR результата */
export const resultUrl = (score: number, attemptId: string) =>
  `https://punchnet.online/r?score=${score}&id=${attemptId}`
